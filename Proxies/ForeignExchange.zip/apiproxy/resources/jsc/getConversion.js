// ExpiryToken expiry time from seconds to milliseconds with a default
var convert = 5;
var bResponse= context.getVariable("response.content");

var rData = JSON.parse(bResponse);
print(JSON.stringify(rData.getProductFXRatesResponse));

var currencies=rData.getProductFXRatesResponse.Supplier.Product.CurrencyTranslationRate;
var second_currency = context.getVariable("df.second_currency");
if(currencies.length > 0) {
    for (i=0; i<currencies.length; i++) {
        if(currencies[i].TargetCurrency == second_currency) {
            convert = currencies[i].SourceToTargetCurrencyRate;
        }
    }
}
context.setVariable('df.convert', convert);